package com.example.staffhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaffhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
