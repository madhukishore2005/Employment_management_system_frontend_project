package com.example.staffhub.service;

import com.example.staffhub.entity.LeaveRequest;
import com.example.staffhub.repository.LeaveRequestRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LeaveRequestService {

    private final LeaveRequestRepository leaveRequestRepository;

    public LeaveRequestService(LeaveRequestRepository leaveRequestRepository) {
        this.leaveRequestRepository = leaveRequestRepository;
    }

    public List<LeaveRequest> getAllLeaves() {
        return leaveRequestRepository.findAll();
    }

    public List<LeaveRequest> getLeavesByEmployee(Long employeeId) {
        return leaveRequestRepository.findByEmployeeId(employeeId);
    }

    public LeaveRequest saveLeaveRequest(LeaveRequest leaveRequest) {
        leaveRequest.setStatus("PENDING");
        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest updateLeaveStatus(Long id, String status) {
        LeaveRequest leave = leaveRequestRepository.findById(id).orElse(null);
        if (leave != null) {
            leave.setStatus(status);
            return leaveRequestRepository.save(leave);
        }
        return null;
    }

    public void deleteLeave(Long id) {
        leaveRequestRepository.deleteById(id);
    }
}
